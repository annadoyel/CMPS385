#include <iostream>
#include <vector>
using namespace std;

// merge arrays
void merge(vector<int>& arr, int left, int mid, int right) 
{
    int n1 = mid - left + 1;
    int n2 = right - mid;

    //temporary
    vector<int> leftArray(n1), rightArray(n2);

    //implement them to arrays
    for (int i = 0; i < n1; ++i) 
    {
        leftArray[i] = arr[left + i];
    }
    for (int j = 0; j < n2; ++j) 
    {
        rightArray[j] = arr[mid + 1 + j];
    }

    //merge back into array
    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (leftArray[i] <= rightArray[j]) 
        {
            arr[k] = leftArray[i];
            ++i;
        }
        else 
        {
            arr[k] = rightArray[j];
            ++j;
        }
        ++k;
    }

    //remaining elements of leftArray, if any then copying it 
    while (i < n1) 
    {
        arr[k] = leftArray[i];
        ++i;
        ++k;
    }

    //remaining elements of rightArray, if any copy it 
    while (j < n2) 
    {
        arr[k] = rightArray[j];
        ++j;
        ++k;
    }
}

//Merge function
void mergeSort(vector<int>& arr, int left, int right) 
{
    if (left < right) 
    {
        int mid = left + (right - left) / 2;

        //sort first and second 
        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);

        //merge the halves sorted
        merge(arr, left, mid, right);
    }
}

//binary search function
int binarySearch(const vector<int>& arr, int left, int right, int key)
{
    while (left <= right) 
    {
        int mid = left + (right - left) / 2;

        //check if the key is present at mid
        if (arr[mid] == key) {
            return mid;
        }

        //and if the key is smaller than mid, it is in the left subarray
        if (arr[mid] > key) 
        {
            right = mid - 1;
        }
        else //otherwise it is in the right subarray
        { 
            left = mid + 1;
        }
    }

    // when not found
    return -1;
}

int main() 
{
    //array
    vector<int> arr = { 12, 11, 13, 5, 6, 7 };
    int n = arr.size();

    cout << "Original array: ";
    for (int i = 0; i < n; ++i) 
    {
        cout << arr[i] << " ";
    }
    cout << endl;

    //sort the array using Merge Sort
    mergeSort(arr, 0, n - 1);

    cout << "Sorted array: ";
    for (int i = 0; i < n; ++i)
    {
        cout << arr[i] << " ";
    }
    cout << endl;

    //Binary Search executing 
    int key;
    cout << "Enter the element to search: ";
    cin >> key;

    int result = binarySearch(arr, 0, n - 1, key);

    if (result != -1) 
    {
        cout << "Element found at index " << result << endl;
    }
    else
    {
        cout << "Element not found" << endl;
    }

    return 0;
}

