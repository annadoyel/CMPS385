#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Node 
{
    int order;
    bool isLeaf;
    vector<int> keys;
    vector<Node*> children;
    Node* parent;

    Node(int order, bool isLeaf) : order(order), isLeaf(isLeaf), parent(nullptr) {}

    void insert(int key) 
    {
        if (isLeaf) 
        {
            keys.push_back(key);
            sort(keys.begin(), keys.end());
            if (keys.size() == order) 
            {
                split();
            }
        }
        else 
        {
            int i = 0;
            while (i < keys.size() && key > keys[i])
            {
                i++;
            }
            children[i]->insert(key);
            if (children[i]->keys.size() == order)
            {
                splitChild(i);
            }
        }
    }

    void split() 
    {
        Node* rightChild = new Node(order, isLeaf);
        int mid = order / 2;

        // Copy the right half keys and children to the right child
        for (int i = mid; i < keys.size(); i++) 
        {
            rightChild->keys.push_back(keys[i]);
        }
        if (!isLeaf) 
        {
            for (int i = mid + 1; i < children.size(); i++) 
            {
                rightChild->children.push_back(children[i]);
                children[i]->parent = rightChild; // Assign parent
            }
        }

        keys.resize(mid);
        children.resize(mid + 1);
        children[mid] = rightChild;
        rightChild->parent = parent; // Assign parent

        if (parent) 
        {
            parent->splitChild(parent->children.size() - 1);
        }
        else 
        {
            Node* root = new Node(order, false);
            root->keys.push_back(keys[mid - 1]);
            root->children.push_back(this);
            root->children.push_back(rightChild);
            this->parent = root;
            rightChild->parent = root;
        }
    }

    void splitChild(int i) 
    {
        Node* child = children[i];
        Node* rightChild = new Node(order, child->isLeaf);

        int mid = order / 2;
        for (int j = mid; j < child->keys.size(); j++) 
        {
            rightChild->keys.push_back(child->keys[j]);
        }
        if (!child->isLeaf) 
        {
            for (int j = mid + 1; j < child->children.size(); j++) 
            {
                rightChild->children.push_back(child->children[j]);
                child->children[j]->parent = rightChild; // Assign parent
            }
        }

        child->keys.resize(mid);
        child->children.resize(mid + 1);
        children.insert(children.begin() + i + 1, rightChild);
        rightChild->parent = this;

        keys.insert(keys.begin() + i, child->keys[mid - 1]);
    }
};

class BTree 
{
public:
    BTree(int order) : root(new Node(order, true)) {}

    void insert(int key) 
    {
        root->insert(key);
    }

private:
    Node* root;
};

int main() 
{
    BTree tree(3); // Create a B-tree of order 3

    // Insert keys as shown in the example images
    tree.insert(78);
    tree.insert(52);
    tree.insert(81);
    tree.insert(40);
    tree.insert(33);
    tree.insert(90);
    tree.insert(85);
    tree.insert(20);
    tree.insert(38);


    return 0;
}