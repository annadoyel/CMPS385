#include <iostream>
#include <vector>

using namespace std;

const int INF = 1000000; //large value to make sure it will cover

//vertex with the minimum key value from the set not included in MST yet 
int minKey(vector<int>& key, vector<bool>& included, int V) 
{
    int min = INF, min_index;

    for (int v = 0; v < V; v++) 
    {
        if (!included[v] && key[v] < min)
        {
            min = key[v];
            min_index = v;
        }
    }
    return min_index;
}

//print MST stored in parent[]
void printMST(vector<int>& parent, vector<vector<int>>& graph, int V) 
{
    int totalWeight = 0;
    cout << "Edge \tWeight\n";
    for (int i = 1; i < V; i++)
    {
        cout << parent[i] + 1 << " - " << i + 1 << "\t" << graph[i][parent[i]] << "\n";
        totalWeight += graph[i][parent[i]];
    }
    cout << "Total Weight of MST: " << totalWeight << endl;
}

//construct and print MST for a graph using adjacency matrix 
void primMST(vector<vector<int>>& graph, int V) 
{
    //store constructed MST
    vector<int> parent(V);

    //Key values - pick minimum weight edge in cut
    vector<int> key(V, INF);

    //represent set of vertices in MST
    vector<bool> included(V, false);

    //make sure to include the first vertex in MST.
    key[0] = 0;       //key 0 to make pick as 1st vertex
    parent[0] = -1;   //1st node is root of MST

    for (int count = 0; count < V - 1; count++) 
    {
        //minimum key vertex of vertices not included MST
        int u = minKey(key, included, V);

        //add picked vertex 
        included[u] = true;

        //update key of the adjacent vertices 
        for (int v = 0; v < V; v++) 
        {
            //update the key when smaller than key v
            if (graph[u][v] && !included[v] && graph[u][v] < key[v]) 
            {
                parent[v] = u;
                key[v] = graph[u][v];
            }
        }
    }

    //call print function
    printMST(parent, graph, V);
}


int main() 
{
    //vertices
    int V = 9;

    //adjacency matrix graph
    vector<vector<int>> graph = 
    {
        {0, 1, 4, INF, INF, INF, INF, INF, INF},
        {1, 0, 2, 8, INF, INF, INF, INF, INF},
        {4, 2, 0, INF, 2, 5, INF, INF, INF},
        {INF, 8, INF, 0, 11, INF, 9, INF, INF},
        {INF, INF, 2, 11, 0, 6, INF, 3, INF},
        {INF, INF, 5, INF, 6, 0, INF, INF, 8},
        {INF, INF, INF, 9, INF, INF, 0, 7, 4},
        {INF, INF, INF, INF, 3, INF, 7, 0, 3},
        {INF, INF, INF, INF, INF, 8, 4, 3, 0}
    };

    //prim's algorithm
    primMST(graph, V);

    return 0;
}
