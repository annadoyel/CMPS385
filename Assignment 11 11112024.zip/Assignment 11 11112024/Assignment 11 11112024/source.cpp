#include <iostream>
#include <vector> //storing dynamic arrays 
#include <queue> //selecting the vertex with the smallest distance in dijkstra algorithm
#include <climits> //initialize distances to infinity
#include <functional> //comparator to order the priority queue in ascending order

using namespace std;

// structure to represent each edge
struct Edge
{
    int destination;
    int weight;
};

// structure for each node
struct Vertex
{
    int id;
    int dist;
    Vertex* path;

    // comparator for priority queue + sorting vertices 
    bool operator>(const Vertex& other) const
    {
        return dist > other.dist;
    }
};

// dijkstra implementation
void dijkstra(int numVertices, vector<vector<Edge>>& graph, int start, vector<int>& dist, vector<Vertex*>& path)
{
    // initiator
    dist.assign(numVertices, INT_MAX); // set all distances to infinity
    path.assign(numVertices, nullptr); // initialize path to nullptr
    vector<bool> visited(numVertices, false); // to track visited vertices

    // priority queue
    priority_queue<Vertex, vector<Vertex>, greater<Vertex>> pq;

    // initiator of the vertex
    dist[start] = 0;
    Vertex startVertex{ start, 0, nullptr }; // create start vertex
    pq.push(startVertex); // add start vertex to the priority queue

    while (!pq.empty())
    {
        // vertex with the smallest distance
        Vertex current = pq.top();
        pq.pop();

        int u = current.id;

        // in case vertex been visited, go to next
        if (visited[u]) continue;
        visited[u] = true;

        // process all adjacents
        for (const Edge& edge : graph[u])
        {
            int v = edge.destination;
            int weight = edge.weight;

            // checking for a shorter path 
            if (dist[u] + weight < dist[v])
            {
                dist[v] = dist[u] + weight; // update the distance to v
                path[v] = &current; // update the predecessor path
                Vertex newVertex{ v, dist[v], &current }; // create new vertex for v
                pq.push(newVertex); // push the updated vertex into the priority queue
            }
        }
    }
}

// output
void printResult(int numVertices, const vector<int>& dist, const vector<Vertex*>& path) 
{
    for (int i = 0; i < numVertices; i++) {
        cout << "Distance to vertex " << i << ": " << dist[i] << "\n";  // return shortest distance 

        if (path[i] != nullptr) 
        {    // if path exists 
            cout << "Path: ";
            // destination vertex and tracing path 
            Vertex* v = path[i];   

            // reconstructing it
            vector<int> reconstructed_path; // storing
            while (v != nullptr) 
            {    // traversing it
                reconstructed_path.push_back(v->id);   
                v = v->path;    
            }

            // returning
            
            for (int j = reconstructed_path.size() - 1; j >= 0; j--) 
            {
                cout << reconstructed_path[j] << " ";    
            }
            cout << "\n";
        }
        else 
        {
            cout << "No path\n";   
        }
    }
}

int main() 
{
    // vertices 
    int numVertices = 5;

    // adjacency list
    vector<vector<Edge>> graph(numVertices);   

    // edges
    graph[0].push_back({ 1, 10 });
    graph[0].push_back({ 2, 5 });
    graph[1].push_back({ 2, 2 });
    graph[1].push_back({ 3, 1 });
    graph[2].push_back({ 1, 3 });
    graph[2].push_back({ 3, 9 });
    graph[3].push_back({ 4, 4 });
    graph[4].push_back({ 0, 7 });

    vector<int> dist;
    vector<Vertex*> path;

    dijkstra(numVertices, graph, 0, dist, path);

    // output
    printResult(numVertices, dist, path);

    return 0;
}
