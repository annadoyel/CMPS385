#include <iostream>

using namespace std;

struct AVLNode 
{
    int info;
    AVLNode* left;
    AVLNode* right;
    int height;
};

int height(AVLNode* node) 
{
    if (node == nullptr) 
    {
        return 0;
    }
    return node->height;
}

int getBalance(AVLNode* node) 
{
    if (node == nullptr) 
    {
        return 0;
    }
    return height(node->left) - height(node->right);
}

AVLNode* rightRotate(AVLNode* y) 
{
    AVLNode* x = y->left;
    AVLNode* T2 = x->right;

    // Perform rotation
    x->right = y;
    y->left = T2;

    // Update heights
    y->height = max(height(y->left), height(y->right)) + 1;
    x->height = max(height(x->left), height(x->right)) + 1;

    return x;
}

AVLNode* leftRotate(AVLNode* x) 
{
    AVLNode* y = x->right;
    AVLNode* T2 = y->left;

    // Perform rotation
    y->left = x;
    x->right = T2;

    // Update heights
    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;

    return y;
}

AVLNode* insert(AVLNode* node, int info) 
{
    if (node == nullptr) 
    {
        AVLNode* newNode = new AVLNode();
        newNode->info = info;
        newNode->left = newNode->right = nullptr;
        newNode->height = 1;
        return newNode;
    }

    if (info < node->info) 
    {
        node->left = insert(node->left, info);
    }
    else if (info > node->info) 
    {
        node->right = insert(node->right, info);
    }
    else 
    {
        return node; // Duplicate keys are not allowed
    }

    // Update height
    node->height = max(height(node->left), height(node->right)) + 1;

    // Check for balance
    int balance = getBalance(node);

    // Left-Left case
    if (balance > 1 && info < node->left->info) 
    {
        return rightRotate(node);
    }

    // Right-Right case
    if (balance < -1 && info > node->right->info) 
    {
        return leftRotate(node);
    }

    // Left-Right case
    if (balance > 1 && info > node->left->info) 
    {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    // Right-Left case
    if (balance < -1 && info < node->right->info) 
    {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}

AVLNode* minValueNode(AVLNode* node) 
{
    AVLNode* current = node;
    while (current->left != nullptr)
    {
        current = current->left;
    }
    return current;
}

AVLNode* deleteNode(AVLNode* root, int info) 
{
    if (root == nullptr)
    {
        return root;
    }

    if (info < root->info)
    {
        root->left = deleteNode(root->left, info);
    }
    else if (info > root->info) 
    {
        root->right = deleteNode(root->right, info);
    }
    else 
    {
        // Node with only one or no child
        if (root->left == nullptr || root->right == nullptr)
        {
            AVLNode* temp = root->left ? root->left : root->right;

            // No child case
            if (temp == nullptr) 
            {
                temp = root;
                root = nullptr;
            }
            else 
            {
                *root = *temp; // Copy the only child's contents to root
            }

            free(temp);
        }
        else
        {
            // Node with two children: Get the inorder successor (smallest node in the right subtree)
            AVLNode* temp = minValueNode(root->right);

            // Copy the inorder successor's data to this node
            root->info = temp->info;

            // Recursively delete the inorder successor
            root->right = deleteNode(root->right, temp->info);
        }
    }

    if (root == nullptr) 
    {
        return root;
    }

    // Update height
    root->height = max(height(root->left), height(root->right)) + 1;

    // Check for balance
    int balance = getBalance(root);

    // Left-Left case
    if (balance > 1 && info < root->left->info) 
    {
        return rightRotate(root);
    }

    // Right-Right case
    if (balance < -1 && info > root->right->info) 
    {
        return leftRotate(root);
    }

    // Left-Right case
    if (balance > 1 && info > root->left->info) 
    {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }

    // Right-Left case
    if (balance < -1 && info < root->right->info) 
    {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }

    return root;
}

int createAVL(AVLNode*& T) 
{
    T = nullptr;
    return 0;
}

int insertAVL(AVLNode*& T, int info) 
{
    T = insert(T, info);
    return 0;
}

int deleteAVL(AVLNode*& T, int info) 
{
    T = deleteNode(T, info);
    return 0;
}

void printInOrder(AVLNode* root) 
{
    if (root != nullptr) {
        printInOrder(root->left);
        cout << root->info << " ";
        printInOrder(root->right);
    }
}

int main() 
{
    AVLNode* root = nullptr;

    int input[] = { 16, 18, 12, 17, 9, 14, 19, 15, 11, 5, 3 };
    int n = sizeof(input) / sizeof(input[0]);

    createAVL(root);
    for (int i = 0; i < n; i++) 
    {
        insertAVL(root, input[i]);
    }

    cout << "Inorder traversal of the AVL tree: ";
    printInOrder(root);
    cout << endl;

    int keyToDelete = 12;
    deleteAVL(root, keyToDelete);

    cout << "Inorder traversal of the AVL tree after deleting " << keyToDelete << ": ";
    printInOrder(root);
    cout << endl;

    return 0;
}