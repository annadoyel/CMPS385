#include <iostream>
#include <queue>
#include <vector>
#include <unordered_set> // O(n) where n is the number of vertices in the graph

using namespace std;

class Graph 
{
public:
    // list to store graph
    vector<vector<int>> adjList;

    // constructor to initialize graph 
    Graph(int numVertices) {
        adjList.resize(numVertices);
    }

    // adding edge between vertices
    void addEdge(int u, int v)
    {
        adjList[u].push_back(v);
        adjList[v].push_back(u); // for undirected graph
    }

    // BFS traversal starting from vertex v
    void bfs(int start)
    {
        // creating a visited set so I can keep track of the visited ones
        unordered_set<int> visited;

        // creating a queue for BFS
        queue<int> q;

        // marking the starting point as visited + enqueue it
        visited.insert(start);
        q.push(start);

        while (!q.empty()) 
        {
            // dequeue to process it
            int current = q.front();
            q.pop();
            cout << "Visited: " << current << endl;

            // trying all adjacent vertices
            for (int neighbor : adjList[current]) 
            {
                if (visited.find(neighbor) == visited.end()) 
                { // if neighbor is unvisited
                    visited.insert(neighbor);  // marking as visited
                    q.push(neighbor);          // enqueue of the neighbor
                }
            }
        }
    }
};

int main() 
{
    // creating a graph with 6 vertices 
    Graph g(6);

    // adding edges to the graph
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 3);
    g.addEdge(2, 3);
    g.addEdge(3, 4);
    g.addEdge(4, 5);

    // performing the BFS starting from 0
    cout << "Breadth-First Search starting from vertex 0:" << endl;
    g.bfs(0);

    return 0;
}
