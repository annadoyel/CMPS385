#include <iostream>

using namespace std;

struct Node {
    int data;
    struct Node* next;
    struct Node* prev;
};

void displayLinkedList(struct Node* ptr) {
    cout << "Elements are: \n";
    while (ptr != NULL) {
        cout << ptr->data << " ";
        ptr = ptr->next;
    }
    cout << endl;
}

// Insert an element at a given index in a doubly linked list
struct Node* DoublyInsert(struct Node* head, int index, int data) {
    struct Node* ptr = new Node;
    struct Node* p = head;

    int i = 0;

    // Find the node at the specified index
    while (i != index - 1 && p != NULL) {
        p = p->next;
        i++;
    }

    // Handle edge case: index out of bounds
    if (p == NULL) {
        return head;
    }

    // Update pointers for the new node
    ptr->data = data;
    ptr->next = p->next;
    ptr->prev = p;
    if (p->next != NULL) {
        p->next->prev = ptr;
    }
    p->next = ptr;

    return head;
}

int DoublyDelete(int index, struct Node** head) {
    // Handle edge cases: empty list or invalid index
    if (*head == NULL || index < 0) {
        return -1; // Indicate failure
    }

    struct Node* current = *head;
    int i = 0;

    // Find the node to be deleted
    while (i < index && current != NULL) {
        current = current->next;
        i++;
    }

    // Handle edge case: index out of bounds
    if (current == NULL) {
        return -1; // Indicate failure
    }

    // Handle deleting the head node
    if (i == 0) {
        *head = current->next;
        if (*head != NULL) {
            (*head)->prev = NULL;
        }
    }
    else { // Handle deleting a middle or tail node
        current->prev->next = current->next;
        if (current->next != NULL) {
            current->next->prev = current->prev;
        }
    }

    delete current; // Deallocate the deleted node
    return 0; // Indicate success
}

int main() {
    struct Node* head, * second, * third, * fourth;

    // Create linked list
    head = new Node;
    second = new Node;
    third = new Node;
    fourth = new Node;

    head->data = 5;
    head->next = second;
    second->data = 10;
    second->next = fourth;
    fourth->data = 20;
    fourth->next = NULL;

    // Display linked list
    cout << "Before Inserting: \n";
    displayLinkedList(head);

    // Insert node at index 3
    cout << "After inserting: \n";
    head = DoublyInsert(head, 3, 67);
    displayLinkedList(head);

    // Delete node at index 2
    cout << "After deleting: \n";
    DoublyDelete(2, &head);
    displayLinkedList(head);

    return 0;
}