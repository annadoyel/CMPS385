#include <iostream>

using namespace std;

struct Node 
{
    int data;
    Node* next;
};

Node* top = nullptr;

void Push(int value) 
{
    Node* newNode = new Node; 
    newNode->data = value;
    newNode->next = top;
    top = newNode;
}

int TopandPop() 
{
    if (top == nullptr) {
        cerr << "Stack is empty." << endl;
        return -1; // Or handle empty stack differently
    }

    int topValue = top->data;
    Node* temp = top;
    top = top->next;
    delete temp;
    return topValue;

    // top and pop operations operate on the top of the stack, and that is the most recently added element. The top function doesn't modify the stack but the pop function removes the top element.
}

int main() 
{
    Push(10);
    Push(20);
    Push(30);

    int poppedValue = TopandPop();
    cout << "Popped value: " << poppedValue << endl;

    return 0;
}


