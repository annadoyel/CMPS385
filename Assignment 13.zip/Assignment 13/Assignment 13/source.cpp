#include <iostream>
#include <unordered_set>
#include <vector>
using namespace std;

vector<int> findLongestConsecutiveSequence(vector<int>& nums) 
{
    unordered_set<int> hashTable(nums.begin(), nums.end());
    vector<int> bestSequence;
    int maxLength = 0;

    for (int num : nums) 
    {
        //check start of a sequence
        if (hashTable.find(num - 1) == hashTable.end()) 
        {
            int currentNum = num;
            vector<int> currentSequence;

            //build sequence 
            while (hashTable.find(currentNum) != hashTable.end()) 
            {
                currentSequence.push_back(currentNum);
                currentNum++;
            }

            //longest sequence updatw
            if (currentSequence.size() > maxLength) 
            {
                maxLength = currentSequence.size();
                bestSequence = currentSequence;
            }
        }
    }

    return bestSequence;
}

int main() 
{
    vector<int> input = { 1, 3, 8, 14, 4, 10, 2, 11 };
    vector<int> result = findLongestConsecutiveSequence(input);

    cout << "Longest consecutive sequence: ";
    for (int num : result) 
    {
        cout << num << " ";
    }
    cout << endl;

    return 0;
}
