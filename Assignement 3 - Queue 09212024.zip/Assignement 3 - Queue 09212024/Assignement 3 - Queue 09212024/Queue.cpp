#include <iostream>

using namespace std;

struct QueueNode 
{
    int info;
    QueueNode* nextPtr;
};

class Queue 
{
public:
    Queue();
    ~Queue();
    bool isEmpty() const;
    void enqueue(int newItem);
    int dequeue();
    int getFront() const;

private:
    QueueNode* backPtr;
};

Queue::Queue()
{
    backPtr = nullptr;
}

Queue::~Queue() 
{
    while (!isEmpty()) 
    {
        dequeue();
    }
}

bool Queue::isEmpty() const 
{
    return backPtr == nullptr;
}

void Queue::enqueue(int newItem) 
{
    QueueNode* newNode = new QueueNode;
    newNode->info = newItem;

    if (isEmpty()) 
    {
        newNode->nextPtr = newNode;
        backPtr = newNode;
    }
    else 
    {
        newNode->nextPtr = backPtr->nextPtr;
        backPtr->nextPtr = newNode;
        backPtr = newNode;
    }
}

int Queue::dequeue() 
{
    if (isEmpty()) 
    {
        cerr << "Queue is empty. Cannot dequeue." << endl;
        return -1; // Or throw an exception
    }

    QueueNode* frontPtr = backPtr->nextPtr;
    int item = frontPtr->info;

    if (frontPtr == backPtr)
    {
        backPtr = nullptr;
    }
    else
    {
        backPtr->nextPtr = frontPtr->nextPtr;
    }

    delete frontPtr;
    return item;
}

int Queue::getFront() const
{
    if (isEmpty()) 
    {
        cerr << "Queue is empty. Cannot get front." << endl;
        return -1; // Or throw an exception
    }

    return backPtr->nextPtr->info;
}

int main()
{
    Queue q;

    q.enqueue(1);
    q.enqueue(2);
    q.enqueue(3);

    cout << "Dequeued: " << q.dequeue() << endl;
    cout << "Dequeued: " << q.dequeue() << endl;

    q.enqueue(4);
    q.enqueue(5);

    cout << "Front element: " << q.getFront() << endl;

    return 0;
}