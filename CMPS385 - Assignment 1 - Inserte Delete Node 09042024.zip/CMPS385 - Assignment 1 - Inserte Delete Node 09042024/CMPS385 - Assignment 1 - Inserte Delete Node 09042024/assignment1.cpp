#include <iostream>

using namespace std;

struct node {
    int data;
    struct node* next;
};

struct node* head;

void print() {
    node* temp = head;
    while (temp != nullptr) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

void insert(int data, int n) {
    node* temp1 = new node();
    temp1->data = data;
    temp1->next = nullptr;
    if (n == 1) {
        temp1->next = head;
        head = temp1;
        return;
    }

    node* temp2 = head;
    for (int i = 0; i < n - 2; i++) {
        temp2 = temp2->next;
    }
    temp1->next = temp2->next;
    temp2->next = temp1;
}

void delete(int n) {
    node* temp1 = head;

    // Handle deleting the head node
    if (n == 1) {
        head = temp1->next;
        delete temp1;
        return;
    }

    // Traverse to the node before the one to be deleted
    for (int i = 0; i < n - 2; i++) {
        temp1 = temp1->next;
    }

    // Ensure temp1 is not null before proceeding
    if (temp1 != nullptr && temp1->next != nullptr) {
        node* temp2 = temp1->next;
        temp1->next = temp2->next;
        delete temp2;
    }
}

int main() {
    head = nullptr; // empty list
    insert(2, 1); // list: 2
    insert(3, 2); // list: 2,3
    insert(4, 1); // list: 4,2,3
    insert(5, 2); // list: 4,5,2,3
    cout << "This is the inserted linked list: ";
    print();

    cout << endl;
    head = nullptr; // empty list
    insert(2, 1); // list: 2
    insert(3, 2); // list: 2,3
    insert(4, 1); // list: 4,2,3
    insert(5, 2); // list: 4,5,2,3
    print();

    int n;
     delete(n);
    cout << "This is now after deleting it: ";
    print();

    return 0;
}