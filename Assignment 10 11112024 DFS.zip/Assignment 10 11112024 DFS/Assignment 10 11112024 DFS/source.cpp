#include <iostream>
#include <stack>
#include <vector>
#include <unordered_set>  // O(n) where n is the number of vertices in the graph

using namespace std;

class Graph 
{
public:
    vector<vector<int>> adjList;  // adjancency to store graph

    // constructor to initialize graph 
    Graph(int numVertices) 
    {
        adjList.resize(numVertices);
    }

    // edge between vertices
    void addEdge(int u, int v) 
    {
        adjList[u].push_back(v);
        adjList[v].push_back(u);  // undirected graph
    }

    // DFS or DFT
    void dfs(int start)
    {
        unordered_set<int> visited;  //track
        stack<int> s;  // stacking 

        // starting vertex  and mark visited
        s.push(start);
        visited.insert(start);

        while (!s.empty()) 
        {
            int current = s.top();
            s.pop();
            cout << "Visited: " << current << endl;

            // adjacent vertices of current value
            bool foundUnvisitedNeighbor = false;
            for (int neighbor : adjList[current]) 
            {
                if (visited.find(neighbor) == visited.end())
                {  // to see if its unvisited
                    s.push(neighbor);  // push the neighbor 
                    visited.insert(neighbor);  // marking to visited
                    foundUnvisitedNeighbor = true;
                    break;  // only one at a time
                }
            }

            // unvisited neighbor unfound = backtracks by popping
            if (!foundUnvisitedNeighbor) 
            {
                
            }
        }
    }
};

int main() 
{
    // creating a graph with 6 vertices 
    Graph g(6);

    // adding edges to the graph
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 3);
    g.addEdge(2, 3);
    g.addEdge(3, 4);
    g.addEdge(4, 5);

    // performing the DFS starting from 0
    cout << "Depth-First Search starting from vertex 0:" << endl;
    g.dfs(0);

    return 0;
}
